import tkinter as tk
import tkinter.messagebox
import operate_queue as OpQueue
import operate_link as OpLink
import operate_tree as OpTree
import prompt_window as pw
import build_DS as bd
import tool_function as tf


def main():
    root = tk.Tk()
    v = tk.IntVar()
    App = Application(master=root, v=v)
    App.mainloop()


class Application(tk.Frame):
    # Application构造函数
    def __init__(self, v, master=None):
        tk.Frame.__init__(self, master)
        self.init_dataStruct_type()  # 初始化数据结构类型 标记变量
        self.init_set_btn()  # 初始化操作按钮的九个标记变量
        self.init_welcomeWin(v, master)
        self.init_attributes()

    # 初始化类的属性
    def init_attributes(self):
        self.main_win = None
        self.queue_msize_win = None
        self.main_link = None
        self.main_queue = None
        self.main_tree = None
        self.press_del_flag = False
        self.press_add_flag = False
        self.press_revise_flag = False
        self.link_content_entry_var_del = None
        self.link_content_entry_var_add = None
        self.link_content_entry_pos_add = None
        self.link_content_entry_Ovar_revise = None
        self.link_content_entry_Nvar_revise = None
        self.queue_content_entry_var_add = None
        self.tree_content_entry_var_add = None
        self.tree_content_entry_var_del = None
        self.tree_entry_his_num = None
        self.link_entry_his_num = None
        self.queue_entry_his_num = None
        self.history_win1 = None
        self.history_win2 = None
        self.entry_his_num = None
        self.press_load_flag = False
        self.is_tree_his = False
        self.is_link_his = False
        self.is_queue_his = False
        self.tree_history_val_lst = []
        self.link_history_val_lst = []
        self.queue_history_val_lst = []
        self.tree_history_val_lst = []
        self.tree_del_node_win = None
        self.link_del_node_win = None
        self.queue_add_node_win = None
        self.link_add_node_win = None
        self.tree_add_node_win = None

    # 初始化RadioButton
    def init_welcomeWin(self, v, master):
        # 欢迎窗口定义
        self.main_win1 = master
        self.main_win1.title('欢迎')
        self.main_win1.geometry('400x300+550+250')
        self.rd_btn_tree = None
        self.rd_btn_link = None
        self.rd_btn_queue = None
        v.set(0)
        fuc_list = [(self.rd_btn_tree, '二叉搜索树', self.set_btn_tree, 1), (self.rd_btn_link, '链表', self.set_btn_link, 2),
                    (self.rd_btn_queue, '循环队列', self.set_btn_queue, 3), ]
        # 初始化欢迎界面的RadioButton
        for btn, str_rd, func, var in fuc_list:
            btn = tk.Radiobutton(self.main_win1, text=str_rd, variable=v, value=var,
                                 command=func)
            btn.place(x=150, y=40 + 40 * var)
        self.label_welcome1 = tk.Label(self.main_win1, text='欢迎进入数据结构可视化界面！', font='bold')
        self.label_welcome2 = tk.Label(self.main_win1, text='请选择可视化数据类型：')
        self.label_welcome1.pack(anchor='n')
        self.label_welcome2.place(x=50, y=50)
        self.btn_welcome = tk.Button(self.main_win1, text='进 入', bg='LightBlue', state='disabled')
        self.btn_welcome.place(x=120, y=230)
        self.btn_exit = tk.Button(self.main_win1, text='退 出', bg='LightBlue', command=self.totally_exit)
        self.btn_exit.place(x=200, y=230)

    # 初始化数据结构类型 标记变量
    def init_dataStruct_type(self):
        self.is_tree = False
        self.is_link = False
        self.is_queue = False

    # 初始化各个组件
    def init_main_win_widget(self):
        if not self.is_queue:
            self.main_win1.withdraw()
        self.init_main_win()
        self.init_cvs()
        self.init_main_win_button()  # 初始化主界面的按钮
        self.visualize_DS()  # 可视化数据结构
        if self.is_queue:
            self.queue_msize_win.destroy()
    # 初始化主界面
    def init_main_win(self):
        self.main_win = tk.Tk()
        self.main_win.geometry('1400x780')
        self.main_win.title('数据结构可视化')

    # 初始化主界面的按钮
    def init_main_win_button(self):
        if self.is_tree:
            for i, j, p, k in (
                    ['添加结点', 60, 'LightBlue', self.set_press_add_flag],
                    ['删除结点', 110, 'LightBlue', self.set_press_del_flag],
                    ['查看历史', 410, 'LightBlue', lambda: pw.show_history_win1(self)],
                    ['保    存', 580, '#FF461F', lambda: pw.show_save_win(self)],
                    ['返    回', 630, 'LightBlue', self.back_to_welcomeWin],
                    ['退    出', 680, 'LightBlue', self.totally_exit1]):
                self.btn_op = tk.Button(self.main_win, bg=p, text=i, command=k)
                self.btn_op.place(x=30, y=j)
            for i, j, k in (
                    ['前序周游', 210, lambda: OpTree.pre_order_red_begin(self)],
                    ['中序周游', 260, lambda: OpTree.mid_order_green_begin(self)],
                    ['后序周游', 310, lambda: OpTree.post_order_blue_begin(self)],
                    ['层次周游', 360, lambda: OpTree.level_order_pink_begin(self)]):
                tk.Button(self.main_win, bg='LightBlue', text=i, command=k).place(x=30, y=j)
        if self.is_link:
            for i, j, p, k in (
                    ['添加结点', 60, 'LightBlue', self.set_press_add_flag],
                    ['修改结点', 140, 'LightBlue', self.set_press_revise_flag],
                    ['删除结点', 220, 'LightBlue', self.set_press_del_flag],
                    ['查看历史', 300, 'LightBlue', lambda: pw.show_history_win1(self)],
                    ['保    存', 520, '#FF461F', lambda: pw.show_save_win(self)],
                    ['返    回', 600, 'LightBlue', self.back_to_welcomeWin],
                    ['退    出', 680, 'LightBlue', self.totally_exit1]):
                self.btn_op = tk.Button(self.main_win, bg=p, text=i, command=k)
                self.btn_op.place(x=30, y=j)

        if self.is_queue:
            for i, j, p, k in (
                    ['结点入队', 60, 'LightBlue', self.set_press_add_flag],
                    ['结点出队', 140, 'LightBlue', self.set_press_del_flag],
                    ['查看历史', 220, 'LightBlue', lambda: pw.show_history_win1(self)],
                    ['保    存', 520, '#FF461F', lambda: pw.show_save_win(self)],
                    ['返    回', 600, 'LightBlue', self.back_to_welcomeWin],
                    ['退    出', 680, 'LightBlue', self.totally_exit1]):
                self.btn_op = tk.Button(self.main_win, bg=p, text=i, command=k)
                self.btn_op.place(x=30, y=j)

    # 初始化cvs
    def init_cvs(self):
        # 画布定义
        self.cvs = tk.Canvas(self.main_win, bg='LightGrey', width=1200, height=740)
        self.cvs.place(x=140, y=10)
        if self.is_tree:
            self.cvs['scrollregion'] = (0, 0, 1500, 1000)
            h_bar = tk.Scrollbar(self.main_win, orient='horizontal')
            h_bar.pack(side='bottom', fill='x')
            h_bar.config(command=self.cvs.xview)
            v_bar = tk.Scrollbar(self.main_win, orient='vertical')
            v_bar.pack(side='right', fill='y')
            v_bar.config(command=self.cvs.yview)
            self.cvs.config(xscrollcommand=h_bar.set, yscrollcommand=v_bar.set)
        if self.is_link:
            self.cvs['scrollregion'] = (0, 0, 1500, 1000)
            v_bar = tk.Scrollbar(self.main_win, orient='vertical')
            v_bar.pack(side='right', fill='y')
            v_bar.config(command=self.cvs.yview)
            self.cvs.config(yscrollcommand=v_bar.set)

    # 可视化数据结构
    def visualize_DS(self):
        if self.is_tree:
            bd.build_treeDS(self)
            OpTree.visual_tree(self)
            OpTree.tree_style(self)
        if self.is_link:
            bd.build_linkDS(self)
            self.link_initialing = True
            OpLink.visual_link(self)
        if self.is_queue:
            bd.build_queueDS(self)
            OpQueue.visual_queue(self)
            OpQueue.queue_style(self)

    # 设置‘is_tree=True’
    def set_btn_tree(self):
        self.is_tree = True
        self.is_link = False
        self.is_queue = False
        self.btn_welcome['state'] = 'normal'
        self.btn_welcome['command'] = self.init_main_win_widget  # 调用初始化部件函数

    # 设置‘is_link=True’
    def set_btn_link(self):
        self.is_link = True
        self.is_tree = False
        self.is_queue = False
        self.btn_welcome['state'] = 'normal'
        self.btn_welcome['command'] = self.init_main_win_widget  # 调用初始化部件函数

    # 设置‘is_queue=True’
    def set_btn_queue(self):
        self.is_queue = True
        self.is_link = False
        self.is_tree = False
        self.btn_welcome['state'] = 'normal'
        self.btn_welcome['command'] = lambda: pw.show_queue_msize_win(self)  # 调用初始化部件函数

    # 初始化按钮标志
    def init_set_btn(self):
        if self.is_tree:
            self.tree_press_add = False
            self.tree_press_revise = False
            self.tree_press_del = False
        if self.is_queue:
            self.queue_press_add = False
            self.queue_press_revise = False
            self.queue_press_del = False
        if self.is_link:
            self.link_press_add = False
            self.link_press_revise = False
            self.link_press_del = False

    # 设置'self.(queue,link,tree)press_add'
    def set_press_add_flag(self):
        self.press_add_flag = True
        self.press_del_flag = False
        self.press_revise_flag = False
        self.press_load_flag = False
        pw.show_add_node_win(self)

    # 设置'self.(queue,link,tree)press_revise'
    def set_press_revise_flag(self):
        self.press_revise_flag = True
        self.press_del_flag = False
        self.press_add_flag = False
        self.press_load_flag = False
        pw.show_revise_node_win(self)

    # 设置'self.(queue,link,tree)press_del'
    def set_press_del_flag(self):
        self.press_del_flag = True
        self.press_add_flag = False
        self.press_revise_flag = False
        self.press_load_flag = False
        if self.is_tree:
            pw.show_del_node_win(self)
        elif self.is_link:
            pw.show_del_node_win(self)
        elif self.is_queue:
            self.judge()

    # 设置'self.(queue,link,tree)press_revise'
    def set_press_load_flag(self):
        self.press_load_flag = True
        self.press_revise_flag = False
        self.press_del_flag = False
        self.press_add_flag = False
        self.judge()

    # 在用户提出'添加'or'修改'or'删除'结点请求之前，先让用户查找该结点能否'添加'or'修改'or‘删除’
    def judge(self):
        # 按下添加结点的操作
        if self.press_add_flag:
            if self.is_tree:
                str_add_data = self.tree_content_entry_var_add.get()
                if not str_add_data.isdigit():
                    tk.messagebox.showwarning(title='二叉搜索树', message='格式错误，请输入数字！')
                    self.tree_add_node_win.destroy()
                else:
                    int_add_data = int(str_add_data)
                    if self.main_tree.search(int_add_data)[0]:
                        tk.messagebox.showwarning(title='二叉搜索树',
                                                  message='结点值为{}的结点已经在当前二叉搜索树中，无法插入！'.format(int_add_data))
                        self.tree_add_node_win.destroy()
                    else:
                        OpTree.insert_tree_node(self, int_add_data)
            if self.is_link:
                add_var = self.link_content_entry_var_add.get()
                add_pos = self.link_content_entry_pos_add.get()
                if not add_pos.isdigit() or not add_var.isdigit():
                    tk.messagebox.showwarning(title='链表', message='格式错误，请输入数字！')
                    self.link_add_node_win.destroy()
                else:
                    if int(add_pos) > self.main_link.get_length() + 1:
                        OpLink.link_add_node_by_pos(self, self.main_link.get_length() + 1, int(add_var))
                    else:
                        OpLink.link_add_node_by_pos(self, int(add_pos), int(add_var))
            if self.is_queue:
                add_data = self.queue_content_entry_var_add.get()
                if self.main_queue.is_full():
                    tk.messagebox.showwarning(title='循环队列', message='当前循环队列已满，无法进行入队操作！')
                else:
                    if not add_data.isdigit():
                        tk.messagebox.showwarning(title='循环队列', message='格式错误，请输入数字！')
                        self.queue_add_node_win.destroy()
                    else:
                        OpQueue.add_queue_node(self, int(add_data))
            self.press_add_flag = False
        # 按下修改结点的操作
        if self.press_revise_flag:
            if self.is_link:
                old_val = self.link_content_entry_Ovar_revise.get()
                new_val = self.link_content_entry_Nvar_revise.get()
                if not old_val.isdigit() or not new_val.isdigit():
                    tk.messagebox.showwarning(title='链表', message='格式错误，请输入数字！')
                    self.link_content_entry_Ovar_revise.delete(0, 'end')
                    self.link_content_entry_Nvar_revise.delete(0, 'end')
                else:
                    if not self.main_link.search_by_val(int(old_val))[0]:
                        tk.messagebox.showwarning(title='链表', message='您所修改的结点不在当前链表中，无法修改！')
                        self.link_content_entry_Ovar_revise.delete(0, 'end')
                        self.link_content_entry_Nvar_revise.delete(0, 'end')
                    else:
                        OpLink.link_revise_node(self, int(old_val), int(new_val))
            self.press_revise_flag = False
        # 按下删除结点的操作
        if self.press_del_flag:
            if self.is_tree:
                if not self.main_tree.is_empty():
                    str_del_data = self.tree_content_entry_var_del.get()
                    if not str_del_data.isdigit():
                        tk.messagebox.showwarning(title='二叉搜索树', message='格式错误，请输入数字！')
                        # self.tree_content_entry_var_del.delete(0, 'end')
                        self.tree_del_node_win.destroy()
                    else:
                        int_del_data = int(str_del_data)
                        if self.main_tree.search(int_del_data) == (False, False):
                            tk.messagebox.showwarning(title='二叉搜索树',
                                                      message='结点值为{}的结点不在当前二叉搜索树中！'.format(int_del_data))
                            self.tree_del_node_win.destroy()
                        else:
                            OpTree.del_tree_node(self, int_del_data)
                            tk.messagebox.showinfo(title='二叉搜索树', message='结点值为{}的结点已删除！'.format(int_del_data))
                else:
                    tk.messagebox.showwarning(title='二叉搜索树', message='当前二叉搜索树为空，没有任何结点，无法删除！')
            elif self.is_link:
                if not self.main_link.is_empty():
                    del_data = self.link_content_entry_var_del.get()
                    if not del_data.isdigit():
                        tk.messagebox.showwarning(title='链表', message='格式错误，请输入数字！')
                        self.link_del_node_win.destroy()
                    else:
                        if not self.main_link.search_by_val(int(del_data))[0]:
                            tk.messagebox.showwarning(title='链表', message='结点值为{}的结点不在当前链表中！'.format(del_data))
                            self.link_del_node_win.destroy()
                        else:
                            OpLink.link_del_node(self, int(del_data))
                else:
                    tk.messagebox.showwarning(title='链表', message='当前链表为空，没有任何结点，无法删除！')
            elif self.is_queue:
                if self.main_queue.is_empty():
                    tk.messagebox.showwarning(title='循环队列', message='当前循环队列为空，无法进行出队操作！')
                else:
                    OpQueue.del_queue_node(self)
            self.press_del_flag = False
        # 按下加载的操作
        if self.press_load_flag:
            history_num = self.entry_his_num.get()
            if self.is_tree:
                his_val_lst = self.tree_history_val_lst
                self.is_tree_his = True
            elif self.is_link:
                his_val_lst = self.link_history_val_lst
                self.is_link_his = True
            else:
                his_val_lst = self.queue_history_val_lst
                self.is_queue_his = True

            if not history_num.isdigit():
                tk.messagebox.showwarning(title='警告', message='格式错误，请输入数字！')
                self.entry_his_num.delete(0, 'end')
            else:
                if int(history_num) > len(his_val_lst) or int(history_num) <= 0:
                    tk.messagebox.showwarning(title='警告', message='该历史数据不存在，请重新输入！')
                    self.entry_his_num.delete(0, 'end')
                else:
                    if self.is_tree_his:
                        tmp_tree_node_ls = []
                        OpTree.clear_cvs(self)
                        self.tree_node_ls = self.tree_history_val_lst[int(history_num) - 1]
                        OpTree.visual_tree(self)
                        '''转换为中位数'''
                        OpTree.pop_null(self)
                        tf.lst_str_int(self.tree_node_ls)
                        tf.cal_median(self.tree_node_ls, tmp_tree_node_ls)
                        self.tree_node_ls = tmp_tree_node_ls
                        ''''''
                        self.is_tree_his = False
                    if self.is_link_his:
                        OpLink.clean_cvs(self)
                        self.link_node_ls = self.link_history_val_lst[int(history_num) - 1]
                        OpLink.visual_link(self)
                        self.is_link_his = False
                    if self.is_queue_his:
                        self.queue_node_ls = self.queue_history_val_lst[int(history_num) - 1]
                        OpQueue.visual_queue(self)
                        self.is_queue_his = False
                    self.history_win1.destroy()
                    tk.messagebox.showinfo(title='提示', message='已成功加载第{}组历史数据！'.format(int(history_num)))
            self.press_load_flag = False

    # 从可视化界面返回到欢迎界面
    def back_to_welcomeWin(self):
        if self.main_win != None:
            self.main_win.withdraw()
        else:
            self.queue_msize_win.destroy()
        self.main_win1.update()
        self.main_win1.deiconify()
        self.main_win1.wm_attributes('-topmost', 1)

    # 彻底退出整个软件(从欢迎界面)
    def totally_exit(self):
        self.main_win1.quit()

    # 彻底退出整个软件(从可视化界面)
    def totally_exit1(self):
        self.main_win.quit()


if __name__ == '__main__':
    main()
