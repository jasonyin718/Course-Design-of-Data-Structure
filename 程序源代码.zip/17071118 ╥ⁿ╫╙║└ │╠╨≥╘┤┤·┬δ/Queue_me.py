'''
    该库是循环队列数据结构的定义库
'''


class Queue(object):
    def __init__(self, max_size, node_list):
        self.m_size = max_size
        self.cur_size = 0
        self.front = 0
        self.rear = 0
        self.qu = [None] * self.m_size
        for i in node_list:
            self.en_queue(i)

    # 创建一个循环队列
    def create_queue(self, node_list):
        for i in node_list:
            self.en_queue(i)

    # 返回当前循环队列的长度
    def get_queLength(self):
        return self.cur_size

    # def delete(self):
    #     del self.qu

    # # 清空队列
    # def clear(self):
    #     self.front = self.rear

    # 查找某个结点是否存在
    # def search(self, data):
    #     if data in self.qu:
    #         return True
    #     return False

    # 如果循环队列未满，向队尾插入元素
    def en_queue(self, data):
        if (self.rear + 1) % self.m_size == self.front:
            print("循环队列当前已满，无法向循环队列中插入结点！")
            return False
        else:
            self.qu[self.rear] = data
            self.rear = (self.rear + 1) % self.m_size
            self.cur_size += 1
            return True

    # 如果循环队列不空，将队尾元素出队
    def de_queue(self):
        if self.front == self.rear:
            print("循环队列当前为空，无任何结点！")
            return False, None
        else:
            data = self.qu[self.front]
            self.qu[self.front] = None
            self.front = (self.front + 1) % self.m_size
            self.cur_size -= 1
            return True, data

    # 得到循环队列的对头元素
    def get_front(self):
        if self.front == self.rear:
            print("循环队列当前为空，没有队头元素！")
            return False
        return self.qu[self.front]

    # 得到循环队列队头元素的下标
    def get_front_pos(self):
        return self.front

    # 得到循环队列队尾元素的下标
    def get_rear_pos(self):
        return self.rear

    # # 得到循环队列的队尾元素
    # def get_rear(self):
    #     if self.front == self.rear:
    #         print("循环队列当前为空，没有队尾元素！")
    #         return False
    #     return self.qu[(self.rear - 1) % self.m_size]

    # 判断循环队列是否为满
    def is_full(self):
        if self.front == (self.rear + 1) % self.m_size:
            return True
        else:
            return False

    # 判断循环队列是否为空
    def is_empty(self):
        if self.front == self.rear:
            return True
        else:
            return False

    # # 输出所有循环队列中的元素
    # def show_queue(self):
    #     for i in range(self.cur_size):
    #         print(self.qu[(i + self.front) % self.m_size], end=' ')
    #

# def main():
#     ls = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
#     queue = Queue(15, ls)
#     print(queue.get_rear())
#     queue.en_queue(12)
#     print(queue.get_rear())
#     # queue.show_queue()
#     # print('\n')
#     # for i in range(0, 5):
#     #     queue.de_queue()
#     # queue.show_queue()
#     # print('\n')
#     # for i in range(0, 5):
#     #     queue.en_queue(i)
#     # queue.show_queue()
#     # print('\n')
#     # print(queue.get_queLength())
#
#
# if __name__ == '__main__':
#     main()
