'''
    这是工具函数库
'''
import math
import threading as td


# 计算中点坐标值，返回（mid_x，mid_y）元组
def cal_mid_point(x1, y1, x2, y2):
    return ((x1 + x2) / 2, (y1 + y2) / 2)


# 将弧度制转化为角度制
def rad_to_dgree(rad):
    return rad * 180 / math.pi


# 求中位数
def cal_median(lst, new_lst):
    if len(lst) == 0:
        return
    lst.sort()
    lst_len = len(lst)
    n = (lst_len - 1) // 2
    new_lst.append(lst[n])
    cal_median(lst[0:n], new_lst)
    cal_median(lst[n + 1:len(lst)], new_lst)


# 将列表中的str变为int
def lst_str_int(lst):
    for i in range(0, len(lst)):
        lst[i] = int(lst[i])


# 计算圆的半径
def queue_cal_radius(x1, y1, x2, y2):
    return (math.sqrt((x1 - x2) ** 2 + (y1 - y2) ** 2)) / (2 * math.sqrt(2))


# 创建新的进程
def create_new_thread(func, *args):
    t = td.Thread(target=func, args=args)
    t.setDaemon(True)
    t.start()
    # t.join()
    # t = threading.Thread(target=func, args = args) 
    #       #  守护 !!!
    #     t.setDaemon(True) 
    #       #  启动
    #     t.start()
    #       #  阻塞--卡死界面！
    #       #  t.join()
