'''
    定义二叉搜索树数据结构的库
'''


class TreeNode(object):  # 定义二叉搜索树的节点信息
    def __init__(self, val):
        self.val = val
        self.left = None
        self.right = None
        self.par = None


class BST(object):
    # 初始化根节点
    def __init__(self, node_list):
        self.root = None
        for node in node_list:
            self.insert(node)

    # 计算得到树的深度
    def treeDepth(self, cur_root):
        if cur_root == None:
            return 0
        leftDepth = self.treeDepth(cur_root.left)
        rightDepth = self.treeDepth(cur_root.right)
        if leftDepth > rightDepth:
            return leftDepth + 1
        if rightDepth >= leftDepth:
            return rightDepth + 1

    # 返回根节点
    def get_root(self):
        return self.root

    # 判断二叉树是否为空
    def is_empty(self):
        if self.root == None:
            return True
        else:
            return False

    # 插入结点
    def insert(self, new_val):
        cur_node = TreeNode(new_val)
        if self.search(cur_node.val)[0] == True:
            print("结点值为{}的结点已经存在于此二叉搜索树中，无法添加！\n".format(cur_node.val))
            return False
        cur_nodeFather = None
        cur = self.root
        while cur != None:
            # 若果待插入cur_node.val已经存在，则不能插入
            if cur.val == cur_node.val:
                return False
            cur_nodeFather = cur
            if cur_node.val < cur.val:
                cur = cur.left
            else:
                cur = cur.right
        # 找倒位置后的插入操作
        cur_node.par = cur_nodeFather
        if cur_nodeFather == None:
            self.root = cur_node
        elif cur_node.val < cur_nodeFather.val:
            cur_nodeFather.left = cur_node
        else:
            cur_nodeFather.right = cur_node

    # 查找二叉树中是否有某个结点
    def search(self, value):
        cur_node = self.root
        while cur_node != None:
            if cur_node.val == value:
                return True, cur_node
            elif cur_node.val < value:
                cur_node = cur_node.right
            else:
                cur_node = cur_node.left
        return False, False  # 没有找到目标结点

    # 查找最小结点
    def find_min(self, root_node):
        if self.is_empty():
            print('二叉搜索树为空，无法进行修锁操作！')
            return False
        else:
            def fm(node):
                if node.left:
                    return fm(node.left)
                else:
                    return node

            return fm(root_node)

    # 查找最大值结点
    def find_max(self, root_node):
        if self.is_empty():
            print('二叉搜索树为空，无法进行搜索操作!')
            return False
        else:
            def fm(node):
                if node.right:
                    return fm(node.right)
                else:
                    return node

            return fm(root_node)

    # 删除某结点
    def delete(self, data):
        is_exist, no_use = self.search(data)
        if not is_exist:
            print('删除操作：二叉搜索树没有节点的值为:', data, '无法执行删除操作')
            return False
        else:
            cur_node = self.root
            while cur_node != None:
                if cur_node.val == data:
                    break
                elif cur_node.val < data:
                    cur_node = cur_node.right
                else:
                    cur_node = cur_node.left
            # 如果该节点是叶节点
            if cur_node.left == None and cur_node.right == None:
                if cur_node == self.root:
                    self.root = None
                    print('二叉搜索树为空！')
                elif cur_node.par.left == cur_node:
                    cur_node.par.left = None
                elif cur_node.par.right == cur_node:
                    cur_node.par.right = None
                    return
                    # 如果该节点只有一个子节点，其父节点直接指向其子节点
            if cur_node.left and cur_node.right == None:
                if cur_node == self.root:
                    self.root.val = cur_node.left.val
                    self.root.left = cur_node.left.left
                else:
                    cur_node.par.left = cur_node.left
                    cur_node.left.par = cur_node.par
                    return
            if cur_node.right and cur_node.left == None:
                if cur_node == self.root:
                    self.root.val = cur_node.right.val
                    self.root.right = cur_node.right.right
                else:
                    cur_node.par.right = cur_node.right
                    cur_node.right.par = cur_node.par
                    return
            # 如果该节点有两个子节点，将其右子树的最小数据替代此节点的数据，并删除有右子树的最小数据
            if cur_node.right and cur_node.left:
                min_right = self.find_min(cur_node.right)
                # cur_node.val = min_right.val
                self.delete(min_right.val)
                cur_node.val = min_right.val

    # # 前序周游
    # def pre_order(self, cur_root):
    #     if cur_root == None:
    #         return
    #     print(cur_root.val, end=' ')
    #     self.pre_order(cur_root.left)
    #     self.pre_order(cur_root.right)
    #
    # # 中序周游
    # def mid_order(self, cur_root):
    #     if cur_root == None:
    #         return
    #     self.mid_order(cur_root.left)
    #     print(cur_root.val, end=' ')
    #     self.mid_order(cur_root.right)
    #
    # # 后序周游
    # def post_order(self, cur_root):
    #     if cur_root == None:
    #         return
    #     self.post_order(cur_root.left)
    #     self.post_order(cur_root.right)
    #     print(cur_root.val, end=' ')
    #
    # # 层次周游
    # def level_order(self, cur_root):
    #     """借助队列（其实还是一个栈）实现层次遍历
    #     """
    #     if cur_root == None:
    #         return
    #     stack = []
    #     stack.append(cur_root)
    #     while stack:
    #         node = stack.pop(0)  # 实现先进先出
    #         print(node.val, end=' ')
    #         if node.left:
    #             stack.append(node.left)
    #         if node.right:
    #             stack.append(node.right)

    # 转换树的结点列表
    def convert_tree_node_ls(self, cur_root, level_order_ls):
        depth = self.treeDepth(self.root)
        full_num = 2 ** depth - 1
        if cur_root == None:
            return
        q = []
        q.append(cur_root)  # 这儿用一个列表模仿入队
        null_tag = 1
        while q and full_num != 0:
            current_node = q.pop(0)  # 将队首元素出队
            if isinstance(current_node, str):
                level_order_ls.append(current_node)
                a = 'null' + str(null_tag)
                q.append(a)
                null_tag += 1
                a = 'null' + str(null_tag)
                q.append(a)
                null_tag += 1
                full_num -= 1
                continue
            else:
                level_order_ls.append(current_node.val)

            if current_node.left == None:
                a = 'null' + str(null_tag)
                q.append(a)
                null_tag += 1
            if current_node.left:  # 判断该节点是否有左孩子
                q.append(current_node.left)
            if current_node.right == None:
                a = 'null' + str(null_tag)
                q.append(a)
                null_tag += 1
            if current_node.right:  # 判断该节点是否有右孩子
                q.append(current_node.right)
            full_num -= 1
        del q


# def main():
#     tree_val_ls = [15, 25, 40, 10, 20, 30, 29, 45, 5, 35, 50]  # 15 25 40 10 20 30 45 5 35 50
#
#     bst = BST(tree_val_ls)
#     bst.mid_order(bst.root)
#     print()
#     bst.delete(15)
#     bst.mid_order(bst.root)
    # bst.pre_order(bst.root)
    # print()
    # bst.level_order(bst.root)
    # bst.insert(bst.root, 31)
    # bst.mid_order(bst.root)
    # print()
    # print("树的深度：", bst.treeDepth(bst.root))
    # print('广度优先遍历顺序：')
    # print('中序周游遍历：', bst.mid_order(bst.root))
    # lo_ls = []
    # bst.level_order(bst.root, lo_ls)
    # print("广度优先遍历列表：", lo_ls)
    # print('\n')
    # print('中序周游遍历顺序：')
    # bst.mid_order(bst.root)
    # bst.delete(bst.root, 25)
    # print("\n\n删除结点25后的中序周游遍历：")
    # bst.mid_order(bst.root)
    # print('\n')
    # print("该二叉树的最小结点：", bst.find_min(bst.root).val)
    # bst.insert(bst.root, TreeNode(35))
    # bst.insert(bst.root, TreeNode(37))
    # bst.mid_order(bst.root)
    # print('\n')


# if __name__ == '__main__':
#     main()
