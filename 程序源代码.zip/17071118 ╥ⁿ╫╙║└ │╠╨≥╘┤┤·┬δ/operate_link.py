'''
    这是一个操作链表的函数库
'''
import tkinter as tk
import tkinter.messagebox
import itertools as it
import tool_function as tf
import build_DS as bd
import Link

my_font_15B = ('微软雅黑', 15, 'bold')


# 可视化link
def visual_link(app):
    load_data_to_lst(app)
    if app.is_link_his:
        bd.load_his_to_DS(app)
    app.link_title = app.cvs.create_text(500, 50, text='链表可视化界面', anchor='c', font=my_font_15B)
    app.link_nodeDic = {}  # 存放link create_text以及create_rectangle以及create_line(arrow)结点的字典
    link_nodeGap_H = 80  # link每两个结点之间的水平空间
    link_nodeGap_V = 100 - 12  # link每两个结点之间的垂直空间
    left_to_right = True  # 开始是“由左向右”画结点和箭头线
    i = 0  # 步进
    link_nodex = 200  # link 每个结点create_text的横坐标
    link_nodey = 130  # link 每个结点create_text的纵坐标
    now_node = app.main_link.get_head().next  # now_node存当前子树的头结点的下一个结点，即第一个结点
    while i <= app.main_link.get_length() - 1:
        '''从左向右依次画link结点'''
        while link_nodex <= 1000 - link_nodeGap_H and left_to_right and now_node != None:
            link_node_labText = now_node.val
            app.link_node = app.cvs.create_text(link_nodex, link_nodey, text=link_node_labText)
            app.link_node_side = app.cvs.create_rectangle(link_nodex - 17, link_nodey - 12, link_nodex + 17,
                                                          link_nodey + 12)
            '''不是最后一个结点就画水平箭头线'''
            if link_nodex < 1000 - link_nodeGap_H:
                app.link_arrow = app.cvs.create_line(link_nodex + 17, link_nodey,
                                                     link_nodex + link_nodeGap_H - 17,
                                                     link_nodey,
                                                     arrow='last')
            '''是最后一个结点就画竖直箭头线'''
            if link_nodex == 1000 - link_nodeGap_H:
                app.link_arrow = app.cvs.create_line(link_nodex, link_nodey + 12, link_nodex,
                                                     link_nodey - 12 + link_nodeGap_V,
                                                     arrow='last')
            app.link_nodeDic[app.link_node] = [link_node_labText, app.link_node_side, app.link_arrow]
            link_nodex += link_nodeGap_H
            now_node = now_node.next
            i += 1
        left_to_right = False  # 方向从 “由左向右” 变为 “由右向左”
        link_nodey += link_nodeGap_V
        link_nodex -= link_nodeGap_H
        '''从右向左依次画link结点'''
        while link_nodex >= 200 and (not left_to_right) and now_node != None:
            link_node_labText = now_node.val
            app.link_node = app.cvs.create_text(link_nodex, link_nodey, text=link_node_labText)
            app.link_node_side = app.cvs.create_rectangle(link_nodex - 17, link_nodey - 12, link_nodex + 17,
                                                          link_nodey + 12)
            '''不是第一个结点就画水平箭头线'''
            if link_nodex > 200:
                app.link_arrow = app.cvs.create_line(link_nodex - 17, link_nodey,
                                                     link_nodex - link_nodeGap_H + 17,
                                                     link_nodey,
                                                     arrow='last')
            '''是第一个结点就画竖直箭头线'''
            if link_nodex == 200:
                app.link_arrow = app.cvs.create_line(link_nodex, link_nodey + 12, link_nodex,
                                                     link_nodey - 12 + link_nodeGap_V,
                                                     arrow='last')
            app.link_nodeDic[app.link_node] = [link_node_labText, app.link_node_side, app.link_arrow]
            link_nodex -= link_nodeGap_H
            now_node = now_node.next
            i += 1
        left_to_right = True
        link_nodey += link_nodeGap_V
        link_nodex += link_nodeGap_H


# 在指定位置添加某个结点
def link_add_node_by_pos(app, pos, data):
    real_pos = pos - 1  # 在link_nodeLst中插入新的元素，真正的位置其实是pos-1
    if pos == len(app.link_node_ls) + 1:
        app.link_node_ls.append(data)
    else:
        app.link_node_ls.insert(real_pos, data)
    app.main_link.insert_by_position(pos, Link.LinkNode(data))
    clean_cvs(app)
    visual_link(app)
    app.link_add_node_win.destroy()
    tk.messagebox.showinfo(title='提示', message='已将结点值为 {}的结点添加到此链表中，作为第{}个结点'.format(data, pos))


# 删除指定元素值的结点
def link_del_node(app, data):
    app.main_link.del_by_val(data)
    i = 0
    while i < len(app.link_node_ls):
        if app.link_node_ls[i] == data:
            app.link_node_ls.pop(i)
        i += 1
    clean_cvs(app)
    visual_link(app)
    app.link_del_node_win.destroy()
    tk.messagebox.showinfo(title='提示', message='已删除结点值为： {}的结点！'.format(data))


# 修改指定元素值的结点成新的值
def link_revise_node(app, old_data, new_data):
    for i in range(0, len(app.link_node_ls)):
        if app.link_node_ls[i] == old_data:
            app.link_node_ls[i] = new_data
    app.main_link.revise_node(old_data, new_data)
    clean_cvs(app)
    visual_link(app)
    app.link_revise_node_win.destroy()
    tk.messagebox.showinfo(title='提示', message='结点值变化：{} ---> {}'.format(old_data, new_data))


# 将画布清空
def clean_cvs(app):
    app.cvs.delete(app.link_title)
    for k, v in app.link_nodeDic.items():
        app.cvs.delete(k)
        app.cvs.delete(v[1])
        app.cvs.delete(v[2])


# 将文件中的历史数据加载到load_data_to_lst中
def load_data_to_lst(app):
    app.link_history_val_lst = []
    with open('link_history', 'r') as f:
        for line in it.islice(f, 0, None):
            tmp_his_lst = line.split()
            tf.lst_str_int(tmp_his_lst)
            app.link_history_val_lst.append(tmp_his_lst)
