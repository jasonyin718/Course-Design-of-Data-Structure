import tool_function as tf
import itertools as it
import tkinter.messagebox as tk


# 执行保存树的功能
def op_save(app, file_path, lst):
    tmp_node_lst = []
    for i in range(0, len(lst)):
        if not 'null' in str(lst[i]):
            tmp_node_lst.append(lst[i])
    with open(file_path, 'a') as f:
        if app.is_tree:
            if tmp_node_lst not in app.tree_history_val_lst:
                for i in tmp_node_lst:
                    f.write(str(i) + ' ')
                f.truncate(f.tell() - 1)
                f.write('\n')
                f.close()
                tk.showinfo(title='提示', message='已成功保存当前二叉搜索树！')
            else:
                f.close()
                tk.showwarning(title='警告', message='该二叉搜索树已保存！请点击“查看历史”按钮查看。')
        if app.is_link:
            if tmp_node_lst not in app.link_history_val_lst:
                for i in tmp_node_lst:
                    f.write(str(i) + ' ')
                f.truncate(f.tell() - 1)
                f.write('\n')
                f.close()
                tk.showinfo(title='提示', message='已成功保存当前链表！')
            else:
                f.close()
                tk.showwarning(title='警告', message='该链表已保存！请点击“查看历史”按钮查看。')
        if app.is_queue:
            if tmp_node_lst not in app.queue_history_val_lst:
                for i in range(app.main_queue.cur_size):
                    f.write(str(app.main_queue.qu[(i + app.main_queue.front) % app.main_queue.m_size]) + ' ')
                f.truncate(f.tell() - 1)
                f.write('\n')
                f.close()
                tk.showinfo(title='提示', message='已成功保存当前循环队列！')
            else:
                f.close()
                tk.showwarning(title='警告', message='该循环队列已保存！请点击“查看历史”按钮查看。')
    # 将文件中的历史数据读入history_val_lst中
    if app.is_tree:
        app.tree_history_val_lst = []
    elif app.is_link:
        app.link_history_val_lst = []
    elif app.is_queue:
        app.queue_history_val_lst = []
    with open(file_path, 'r') as f:
        for line in it.islice(f, 0, None):
            tmp_his_lst = line.split()
            tf.lst_str_int(tmp_his_lst)
            if app.is_tree:
                if tmp_node_lst not in app.tree_history_val_lst:
                    app.tree_history_val_lst.append(tmp_his_lst)
            if app.is_link:
                if tmp_node_lst not in app.link_history_val_lst:
                    app.link_history_val_lst.append(tmp_his_lst)
                    print('app.link_history_val_lst：', app.link_history_val_lst)
            if app.is_queue:
                if tmp_node_lst not in app.queue_history_val_lst:
                    app.queue_history_val_lst.append(tmp_his_lst)
