'''
    该库是链表数据结构的定义库
'''


class LinkNode(object):
    def __init__(self, val):
        self.val = val
        self.next = None


class LinkList(object):
    def __init__(self, node_list):
        self.length = 0
        self.head = LinkNode(None)  # 头结点为空，没有val
        for i in node_list:
            self.add_node(LinkNode(i))

    # 得到头结点
    def get_head(self):
        return self.head

    # 判断链是否为空
    def is_empty(self):
        if self.head == None:
            return True
        else:
            return False

    # # 清空链表
    # def clear_list(self):
    #     self.length = 0
    #     self.head = None

    # 在标尾添加元素
    def add_node(self, this_node):
        if self.is_empty():
            self.head.next = this_node
        elif self.search_by_val(this_node.val)[0]:
            print("该节点已经存在，无法添加！")
            return False
        else:
            node = self.head
            while node.next != None:
                node = node.next
            node.next = this_node
        self.length += 1

    # # 删除尾部结点
    # def remove_node(self):
    #     if self.is_empty():
    #         return False
    #     else:
    #         node = self.head
    #         while node.next.next != None:
    #             node = node.next
    #         node.next = None
    #         self.length -= 1

    # 获取当前链表长度
    def get_length(self):
        return self.length

    # 在指定位置插入结点
    def insert_by_position(self, position, this_node):
        if position == 1 and self.length == 0:
            self.add_node(this_node)
        elif position > self.length + 1:
            print("目标位置大于当前链表长度，无法添加！")
            return False
        elif position == self.length + 1:
            node = self.head
            while node.next != None:
                node = node.next
            node.next = this_node
            self.length += 1
        else:
            index = 0
            node = self.head
            while node.next != None:
                index += 1
                if index == position:
                    this_node.next = node.next
                    node.next = this_node
                    self.length += 1
                    return True
                node = node.next

    # 按指定结点值查找结点
    def search_by_val(self, value):
        if self.is_empty():
            # 该链表为空，没有任何结点可以查询
            return False, None
        node = self.head
        while node != None:
            if node.val == value:
                return True, node
            node = node.next
        return False, None

    # 修改某结点的值
    def revise_node(self, old_value, new_value):
        if self.is_empty():
            # 该链表为空，无法修改结点
            return False
        else:
            is_exist, revised_node = self.search_by_val(old_value)
            if is_exist:
                revised_node.val = new_value
                return True
            else:
                return False

    # 删除指定值的结点
    def del_by_val(self, value):
        if self.is_empty():
            # 该链表为空，无任何结点
            return False
        elif self.search_by_val(value) == False:
            # 该链表中没有结点值为value的结点
            return False
        else:
            node = self.head
            while node.next != None:
                if node.next.val == value:
                    node.next = node.next.next
                    self.length -= 1
                    return True
                node = node.next

    # # 对链表进行遍历
    # def traverse(self):
    #     if self.is_empty():
    #         # 该链表为空
    #         return False
    #     else:
    #         node = self.head
    #         while node.next:
    #             node = node.next
    #             print(node.val, end=' ')
    #         print('\n')
    #         return True

# def main():
#     ls = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]
#     link = LinkList(ls)
#     link.traverse()
#     # link.revise_node(3, 100)
#     position = link.insert_by_position(13, LinkNode(100))
#     print("修改后的链表：", end=' ')
#     link.traverse()
#
#
# if __name__ == '__main__':
#     main()
