'''
    这是操作二叉搜索树的函数库
'''
import tkinter as tk
import tkinter.messagebox
import tool_function as tf
import itertools as it
import build_DS as bd
import BST as Bst
import time as tm

my_font_15B = ('微软雅黑', 15, 'bold')
my_font_12B = ('微软雅黑', 12, 'bold')


# 可视化tree
def visual_tree(app):
    load_data_to_his_lst(app)
    if app.is_tree_his:
        bd.load_his_to_DS(app)
    inputLs_to_visualLs(app)
    app.drawArrow_ls = []  # 存储tree画箭头线的坐标
    app.drawArrow_ls = draw_treeNode(app)
    cur_num = 1  # 当前结点的宽度优先的编号
    '''控制循环的层数，一共有tree_now_nodeNum结点，包括null结点'''
    while 2 * cur_num + 1 <= app.tree_now_nodeNum:
        if app.drawArrow_ls[2 * cur_num] != (None, None, None, None):
            tree_arrow_L = app.cvs.create_line(app.drawArrow_ls[cur_num][2], app.drawArrow_ls[cur_num][3],
                                               app.drawArrow_ls[2 * cur_num][0],
                                               app.drawArrow_ls[2 * cur_num][1], arrow='last')
            for i in app.tree_nodeDic.keys():
                if app.tree_nodeDic[i][0] == 2 * cur_num:
                    app.tree_nodeDic[i].append(tree_arrow_L)
                    break
        if app.drawArrow_ls[2 * cur_num + 1] != (None, None, None, None):
            tree_arrow_R = app.cvs.create_line(app.drawArrow_ls[cur_num][2], app.drawArrow_ls[cur_num][3],
                                               app.drawArrow_ls[2 * cur_num + 1][0],
                                               app.drawArrow_ls[2 * cur_num + 1][1], arrow='last')
            for i in app.tree_nodeDic.keys():
                if app.tree_nodeDic[i][0] == 2 * cur_num + 1:
                    app.tree_nodeDic[i].append(tree_arrow_R)
                    break
        cur_num += 1


# 将文件中的数据转化成画二叉搜索树的数据
def inputLs_to_visualLs(app):
    level_order_list = []
    app.main_tree.convert_tree_node_ls(app.main_tree.root, level_order_list)  # 利用层次周游将node_list进行转换
    app.tree_node_ls = level_order_list


# 画tree结点值以及矩形边框
def draw_treeNode(app):
    app.tree_title = app.cvs.create_text(500, 50, text='二叉搜索树可视化界面', anchor='c', font=my_font_15B)
    app.tree_nodeDic = {}  # 存储tree create_text产生的结点的字典    结点值：[结点编号，create_text，create_rectangle，create_line]
    app.treeNode_mid_pos = []  # 一个列表，每个元素是箭头线的（起点x，起点y，终点x，终点y）
    app.treeNode_mid_pos.append(None)
    app.tree_rect_pos_dic = {}  # key为结点的数值，value为当前结点的rect的坐标参数
    app.tree_text_pos_dic = {}  # key为结点的数值，value为当前结点的text的坐标参数
    indent = None  # 声明每一层的缩进量
    tree_node_rank_nowLayer = 0  # 结点在该层中的序号（从No.0开始排列）
    tree_depth = 0  # 该层的深度
    i = 2
    rate = 1
    root_pos_x, root_pos_y = 0, 0
    root_pos_x = 120 * app.main_tree.treeDepth(app.main_tree.root)
    indent = 40 * app.main_tree.treeDepth(app.main_tree.root)
    root_pos_y = 130  # tree根节点的y值
    tree_start_pos_x = root_pos_x  # 每一层中，最左边结点的x值
    tree_start_pos_y = root_pos_y  # 每一层中，最左边结点的x值
    tree_root = app.cvs.create_text(root_pos_x, root_pos_y,
                                    text=app.tree_node_ls[0])  # tree根节点
    tree_rootSide = app.cvs.create_rectangle(root_pos_x - 17, root_pos_y - 12,
                                             root_pos_x + 17,
                                             root_pos_y + 12)  # 根节点的边框
    app.tree_rect_pos_dic[app.tree_node_ls[0]] = (root_pos_x - 17, root_pos_y - 12,
                                                  root_pos_x + 17, root_pos_y + 12)  # 存储根节点rect的坐标值
    app.tree_text_pos_dic[app.tree_node_ls[0]] = (root_pos_x, root_pos_y)  # 存储根节点text的坐标值
    app.tree_nodeDic[app.tree_node_ls[0]] = [1, tree_root,
                                             tree_rootSide, None]  # [宽度优先的编号(根结点编号为1)，根节点的text控件，根节点rectangle控件]
    rootNode_mid_x = root_pos_x  # rootNode矩形边框下边中点x坐标
    rootNode_mid_y = root_pos_y + 12  # rootNode矩形边框下边中点y坐标
    app.treeNode_mid_pos.append((None, None, rootNode_mid_x, rootNode_mid_y))  # 将根节点的下边框中点坐标存入treeNode_mid_pos
    '''画除了root结点剩下的结点'''
    while i <= len(app.tree_node_ls):
        tree_depth += 1  # 该层节点的深度
        num_oneLayer = 2 ** tree_depth  # 一层结点的总数
        app.tree_now_nodeNum = i - 1  # 当前结点的编号（二叉树中的编号 从No.1开始）

        if app.tree_now_nodeNum <= len(app.tree_node_ls):
            tree_start_pos_x -= indent * rate
            while num_oneLayer != 0 and app.tree_now_nodeNum <= len(app.tree_node_ls):
                tree_node_labText = app.tree_node_ls[app.tree_now_nodeNum]
                if 'null' not in str(tree_node_labText):
                    tree_nodex = tree_start_pos_x + 2 * indent * tree_node_rank_nowLayer * rate
                    tree_nodey = tree_start_pos_y + (tree_depth * 100)
                    '''矩形边框的左上角坐标&右上角坐标'''
                    rect_x1 = tree_nodex - 17
                    rect_y1 = tree_nodey - 12
                    rect_x2 = tree_nodex + 17
                    rect_y2 = tree_nodey + 12

                    tree_node = app.cvs.create_text(tree_nodex, tree_nodey, text=tree_node_labText)
                    tree_node_side = app.cvs.create_rectangle(rect_x1, rect_y1, rect_x2, rect_y2)  # 画结点的矩形边框
                    app.tree_rect_pos_dic[tree_node_labText] = (rect_x1, rect_y1, rect_x2, rect_y2)  # 存储根节点rect的坐标值
                    app.tree_text_pos_dic[tree_node_labText] = (tree_nodex, tree_nodey)  # 存储根节点text的坐标值
                    app.tree_nodeDic[tree_node_labText] = [app.tree_now_nodeNum + 1, tree_node, tree_node_side]
                    '''将当前结点的上边中点和下边中点存到treeNode_mid_pos中 其形式为((上边中点x，上边中点y),(下边中点x，下边中点y))'''
                    app.treeNode_mid_pos.append((tree_nodex, rect_y1, tree_nodex, rect_y2))
                else:
                    app.treeNode_mid_pos.append((None, None, None, None))
                tree_node_rank_nowLayer += 1
                num_oneLayer -= 1
                app.tree_now_nodeNum += 1
            tree_node_rank_nowLayer = 0
        i = i * 2
        rate *= 0.5
    return app.treeNode_mid_pos


# 前序周游显示红色的边框
def pre_order_red(app, cur_root):
    if cur_root == None:
        return
    for i in app.tree_rect_pos_dic.keys():
        if i == cur_root.val:
            a = app.cvs.create_rectangle(app.tree_rect_pos_dic[i][0], app.tree_rect_pos_dic[i][1],
                                         app.tree_rect_pos_dic[i][2], app.tree_rect_pos_dic[i][3],
                                         outline='red', width=4)
            b = app.cvs.create_text(app.tree_text_pos_dic[i][0], app.tree_text_pos_dic[i][1], fill='red', text=i)
            app.update()
            tm.sleep(1.5)
            app.cvs.delete(a)
            app.cvs.delete(b)
            break
    pre_order_red(app, cur_root.left)
    pre_order_red(app, cur_root.right)


# 后序周游显示蓝色的边框
def post_order_blue(app, cur_root):
    if cur_root == None:
        return
    post_order_blue(app, cur_root.left)
    post_order_blue(app, cur_root.right)
    for i in app.tree_rect_pos_dic.keys():
        if i == cur_root.val:
            a = app.cvs.create_rectangle(app.tree_rect_pos_dic[i][0], app.tree_rect_pos_dic[i][1],
                                         app.tree_rect_pos_dic[i][2],
                                         app.tree_rect_pos_dic[i][3], outline='blue', width=4)
            b = app.cvs.create_text(app.tree_text_pos_dic[i][0], app.tree_text_pos_dic[i][1], fill='blue', text=i)
            app.update()
            tm.sleep(1.5)
            app.cvs.delete(a)
            app.cvs.delete(b)
            break


# 中序周游显示绿色的边框
def mid_order_green(app, cur_root):
    if cur_root == None:
        return
    mid_order_green(app, cur_root.left)
    for i in app.tree_rect_pos_dic.keys():
        if i == cur_root.val:
            a = app.cvs.create_rectangle(app.tree_rect_pos_dic[i][0], app.tree_rect_pos_dic[i][1],
                                         app.tree_rect_pos_dic[i][2],
                                         app.tree_rect_pos_dic[i][3], outline='green', width=4)
            b = app.cvs.create_text(app.tree_text_pos_dic[i][0], app.tree_text_pos_dic[i][1], fill='green', text=i)
            app.update()
            tm.sleep(1.5)
            app.cvs.delete(a)
            app.cvs.delete(b)
            break
    mid_order_green(app, cur_root.right)


# 层次周游显示红色的边框
def level_order_pink(app, cur_root):
    if cur_root == None:
        return
    stack = []
    stack.append(cur_root)
    while stack:
        node = stack.pop(0)  # 实现先进先出
        for i in app.tree_rect_pos_dic.keys():
            if i == node.val:
                a = app.cvs.create_rectangle(app.tree_rect_pos_dic[i][0], app.tree_rect_pos_dic[i][1],
                                             app.tree_rect_pos_dic[i][2],
                                             app.tree_rect_pos_dic[i][3], outline='magenta', width=4)
                b = app.cvs.create_text(app.tree_text_pos_dic[i][0], app.tree_text_pos_dic[i][1], fill='magenta',
                                        text=i)
                app.update()
                tm.sleep(1.5)
                app.cvs.delete(a)
                app.cvs.delete(b)
                break
        if node.left:
            stack.append(node.left)
        if node.right:
            stack.append(node.right)


# 清空画布
def clear_cvs(app):
    app.cvs.delete(app.tree_title)
    for i, v in app.tree_nodeDic.items():
        if i == app.main_tree.root.val:
            app.cvs.delete(v[1])
            app.cvs.delete(v[2])
        else:
            app.cvs.delete(v[1])
            app.cvs.delete(v[2])
            app.cvs.delete(v[3])


# null值pop的操作
def pop_null(app):
    i = 0
    while i < len(app.tree_node_ls):
        if 'null' in str(app.tree_node_ls[i]):
            app.tree_node_ls.pop(app.tree_node_ls.index(app.tree_node_ls[i]))
            i = 0
        i += 1


# 插入结点的操作
def insert_tree_node(app, new_val):
    clear_cvs(app)
    tmp_tree_node_ls = []
    pop_null(app)
    app.tree_node_ls.append(new_val)
    '''转换为中位数'''
    tf.cal_median(app.tree_node_ls, tmp_tree_node_ls)
    app.tree_node_ls = tmp_tree_node_ls
    ''''''
    app.main_tree = Bst.BST(app.tree_node_ls)  # 重新构造二叉树的数据结构
    visual_tree(app)
    app.tree_add_node_win.destroy()
    tk.messagebox.showinfo(title='二叉搜索树', message='成功添加结点值为"{}"的结点'.format(new_val))


# 删除数据结构和画布中的val值结点
def del_tree_node(app, val):
    clear_cvs(app)
    app.main_tree.delete(val)
    visual_tree(app)
    app.tree_del_node_win.destroy()


# 二叉搜索树独有的画布内容
def tree_style(app):
    for y, text, fill in (
            [100, '前序周游：', 'red'], [140, '中序周游：', 'blue'], [180, '后序周游：', 'green'], [220, '层次周游：', 'magenta']):
        app.cvs.create_text(50, y, text=text, anchor='w')
        app.cvs.create_rectangle(120, y - 10, 140, y + 10, fill=fill, outline='black')


# 将文件中的历史数据加载到load_data_to_lst中
def load_data_to_his_lst(app):
    # app.tree_history_val_lst.clear()
    app.tree_history_val_lst = []
    with open('tree_history', 'r') as f:
        for line in it.islice(f, 0, None):
            tmp_his_lst = line.split()
            tf.lst_str_int(tmp_his_lst)
            app.tree_history_val_lst.append(tmp_his_lst)


def pre_order_red_begin(app):
    tk.messagebox.showinfo(title='提示', message='开始前序周游可视化！')
    pre_order_red(app, app.main_tree.root)
    tk.messagebox.showinfo(title='提示', message='前序周游可视化已结束！')


def mid_order_green_begin(app):
    tk.messagebox.showinfo(title='提示', message='开始中序周游可视化！')
    mid_order_green(app, app.main_tree.root)
    tk.messagebox.showinfo(title='提示', message='中序周游可视化已结束！')


def post_order_blue_begin(app):
    tk.messagebox.showinfo(title='提示', message='开始后序周游可视化！')
    post_order_blue(app, app.main_tree.root)
    tk.messagebox.showinfo(title='提示', message='后序周游可视化已结束！')


def level_order_pink_begin(app):
    tk.messagebox.showinfo(title='提示', message='开始层次周游可视化！')
    level_order_pink(app, app.main_tree.root)
    tk.messagebox.showinfo(title='提示', message='层次周游可视化已结束！')
