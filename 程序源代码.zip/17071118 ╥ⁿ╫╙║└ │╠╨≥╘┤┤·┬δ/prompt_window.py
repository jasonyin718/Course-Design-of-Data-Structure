'''
    该库是弹窗口的函数库
'''
import tkinter as tk
import tkinter.messagebox
import operate_save as OpSave
import itertools as it
import os as os

my_font_15B = ('微软雅黑', 15, 'bold')
my_font_13 = ('微软雅黑', 13)
my_font_13B = ('微软雅黑', 13, 'bold')
my_font_10 = ('微软雅黑', 10)
my_font_20B = ('微软雅黑', 20, 'bold')


# 显示输入循环队列最大分区的窗口
def show_queue_msize_win(app):
    app.main_win1.withdraw()
    app.queue_msize_win = tk.Toplevel(app.main_win1)
    app.queue_msize_win.geometry('218x155+620+300')
    app.queue_msize_win.title('分区')
    tk.Label(app.queue_msize_win, text='输入分区个数：').place(x=20, y=45)
    tk.Button(app.queue_msize_win, bg='LightBlue', text='进 入', command=lambda: judge_msize(app)).place(x=115,
                                                                                                       y=100)  # command=app.init_main_win_widget
    tk.Button(app.queue_msize_win, bg='LightBlue', text='返 回', command=app.back_to_welcomeWin).place(x=45, y=100)
    app.queue_msize_entry = tk.Entry(app.queue_msize_win)
    app.queue_msize_entry.place(x=110, y=45, width='80')


# 判断输入的循环队列分区是否为数字
def judge_msize(app):
    if app.queue_msize_entry.get().isdigit():
        app.init_main_win_widget()
    else:
        tk.messagebox.showwarning(title='警告', message='格式错误，请输入数字！')
        app.queue_msize_entry.delete(0, 'end')


# 显示‘添加结点’对话框
def show_add_node_win(app):
    if app.is_tree:
        app.tree_add_node_win = tk.Toplevel(master=app.main_win)
        app.tree_add_node_win.title('添加结点')
        app.tree_add_node_win.geometry('218x155+420+100')
        app.tree_label_var_add = tk.Label(app.tree_add_node_win, text='新结点值：')
        app.tree_content_entry_var_add = tk.Entry(app.tree_add_node_win)
        app.tree_btn_add = tk.Button(app.tree_add_node_win, bg='LightBlue', text='添  加', command=app.judge)
        app.tree_label_var_add.place(x=30, y=45)
        app.tree_content_entry_var_add.place(x=100, y=45, width='80')
        app.tree_btn_add.place(x=80, y=100)
    if app.is_link:
        app.link_add_node_win = tk.Toplevel(master=app.main_win)
        app.link_add_node_win.title('添加结点')
        app.link_add_node_win.geometry('218x155+420+100')
        app.link_label_var_add = tk.Label(app.link_add_node_win, text='新结点值：')
        app.link_label_pos_add = tk.Label(app.link_add_node_win, text='插入位次：')
        app.link_content_entry_var_add = tk.Entry(app.link_add_node_win)
        app.link_content_entry_pos_add = tk.Entry(app.link_add_node_win)
        app.link_btn_add = tk.Button(app.link_add_node_win, bg='LightBlue', text='添  加', command=app.judge)
        app.link_label_var_add.place(x=30, y=30)
        app.link_label_pos_add.place(x=30, y=55)
        app.link_content_entry_var_add.place(x=100, y=30, width='80')
        app.link_content_entry_pos_add.place(x=100, y=55, width='80')
        app.link_btn_add.place(x=80, y=100)
    if app.is_queue:
        app.queue_add_node_win = tk.Toplevel(master=app.main_win)
        app.queue_add_node_win.title('添加结点')
        app.queue_add_node_win.geometry('218x155+420+100')
        app.queue_label_var_add = tk.Label(app.queue_add_node_win, text='新结点值：')
        app.queue_content_entry_var_add = tk.Entry(app.queue_add_node_win)
        app.queue_btn_add = tk.Button(app.queue_add_node_win, bg='LightBlue', text='添  加', command=app.judge)
        app.queue_label_var_add.place(x=30, y=45)
        app.queue_content_entry_var_add.place(x=100, y=45, width='80')
        app.queue_btn_add.place(x=80, y=100)


# 显示‘删除结点’的对话窗口
def show_del_node_win(app):
    if app.is_link:
        app.link_del_node_win = tk.Toplevel(master=app.main_win)
        app.link_del_node_win.title('删除结点')
        app.link_del_node_win.geometry('218x155+420+100')
        app.link_label_var_del = tk.Label(app.link_del_node_win, text='删除的结点值：')
        app.link_content_entry_var_del = tk.Entry(app.link_del_node_win)
        app.link_btn_del = tk.Button(app.link_del_node_win, bg='LightBlue', text='删  除', command=app.judge)
        app.link_label_var_del.place(x=30, y=45)
        app.link_content_entry_var_del.place(x=120, y=45, width='80')
        app.link_btn_del.place(x=80, y=100)
    if app.is_tree:
        app.tree_del_node_win = tk.Toplevel(master=app.main_win)
        app.tree_del_node_win.title('删除结点')
        app.tree_del_node_win.geometry('218x155+420+100')
        app.tree_label_var_del = tk.Label(app.tree_del_node_win, text='删除的结点值：')
        app.tree_content_entry_var_del = tk.Entry(app.tree_del_node_win)
        app.tree_btn_del = tk.Button(app.tree_del_node_win, bg='LightBlue', text='删  除', command=app.judge)
        app.tree_label_var_del.place(x=30, y=45)
        app.tree_content_entry_var_del.place(x=120, y=45, width='80')
        app.tree_btn_del.place(x=80, y=100)


# 显示’修改结点‘的窗口
def show_revise_node_win(app):
    if app.is_link:
        app.link_revise_node_win = tk.Toplevel(master=app.main_win)
        app.link_revise_node_win.title('修改结点')
        app.link_revise_node_win.geometry('218x155+420+100')
        app.link_label_Ovar_revise = tk.Label(app.link_revise_node_win, text='原结点值：')
        app.link_label_Nvar_revise = tk.Label(app.link_revise_node_win, text='新结点值：')
        app.link_content_entry_Ovar_revise = tk.Entry(app.link_revise_node_win)
        app.link_content_entry_Nvar_revise = tk.Entry(app.link_revise_node_win)
        app.link_btn_revise = tk.Button(app.link_revise_node_win, bg='LightBlue', text='修  改', command=app.judge)
        app.link_label_Ovar_revise.place(x=30, y=30)
        app.link_label_Nvar_revise.place(x=30, y=55)
        app.link_content_entry_Ovar_revise.place(x=100, y=30, width='80')
        app.link_content_entry_Nvar_revise.place(x=100, y=55, width='80')
        app.link_btn_revise.place(x=80, y=100)


# 显示‘查看历史’的窗口1
def data_history_on_win1(tmp_cvs, btn_next_step, file_path):
    i = 1
    text_pos_x, text_pos_y = 110, 30
    with open(file_path, 'r') as f:
        if os.path.getsize(file_path) == 0:
            tmp_cvs.create_text(250, 100, text='暂无历史数据', fill='red', font=my_font_20B)
            btn_next_step['state'] = 'disabled'
        else:
            for line in it.islice(f, 0, None):
                tmp_cvs.create_text(text_pos_x, text_pos_y, text='数据编号' + str(i) + ':   ' + line, anchor='w',
                                    justify='left', font=my_font_10)
                text_pos_y += 50
                i += 1
        f.close()


def show_history_win1(app):
    if app.is_tree or app.is_link or app.is_queue:
        app.history_win1 = tk.Toplevel(master=app.main_win)
        app.history_win1.title('查看历史')
        app.history_win1.geometry('500x400+420+100')
        tk.Label(app.history_win1, text='历史数据表', font=my_font_15B).place(x=200, y=15)
        tmp_cvs = tk.Canvas(app.history_win1, width=1000, height=250)
        tmp_cvs.place(x=0, y=60)
        tmp_cvs['scrollregion'] = (0, 0, 1500, 1000)
        h_bar = tk.Scrollbar(app.history_win1, orient='horizontal')
        h_bar.pack(side='bottom', fill='x')
        h_bar.config(command=tmp_cvs.xview)
        v_bar = tk.Scrollbar(app.history_win1, orient='vertical')
        v_bar.pack(side='right', fill='y')
        v_bar.config(command=tmp_cvs.yview)
        tmp_cvs.config(xscrollcommand=h_bar.set, yscrollcommand=v_bar.set)
        tk.Button(app.history_win1, text='退   出', bg='LightBlue', command=app.history_win1.destroy).place(x=150, y=325)
        btn_next_step = tk.Button(app.history_win1, text='加  载', bg='LightBlue', command=lambda: show_history_win2(app))
        btn_next_step.place(x=300, y=325)
        if app.is_tree:
            data_history_on_win1(tmp_cvs, btn_next_step, 'tree_history')
        if app.is_link:
            data_history_on_win1(tmp_cvs, btn_next_step, 'link_history')
        if app.is_queue:
            data_history_on_win1(tmp_cvs, btn_next_step, 'queue_history')


# 显示‘查看历史’的窗口2
def show_history_win2(app):
    app.history_win2 = tk.Toplevel(master=app.history_win1)
    app.history_win2.title('查看历史')
    app.history_win2.geometry('218x155+820+300')
    tk.Label(app.history_win2, text='历史数据编号：').place(x=30, y=45)
    app.entry_his_num = tk.Entry(app.history_win2)
    app.entry_his_num.place(x=120, y=45, width='80')
    tk.Button(app.history_win2, bg='LightBlue', text='完  成', command=lambda: app.set_press_load_flag()).place(x=80,
                                                                                                              y=100)


# 显示'保存'的窗口
def show_save_win(app):
    if app.is_tree:
        OpSave.op_save(app, 'tree_history', app.tree_node_ls)
    if app.is_link:
        OpSave.op_save(app, 'link_history', app.link_node_ls)
    if app.is_queue:
        OpSave.op_save(app, 'queue_history', app.main_queue.qu)


# def show_graph_val_win(app):
#     app.graph_val_win = tk.Toplevel(app.main_win)
#     app.