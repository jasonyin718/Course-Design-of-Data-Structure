'''
    建立三种数据结构的函数库
'''
import Queue_me as Qu
import BST as Bst
import Link as Link
import tool_function as tf


# 初始化二叉搜索树
def build_treeDS(app):
    tmp_tree_node_ls = []
    app.tree_node_ls = init_nodeList('initial_tree_file')
    '''转换为中位数'''
    tf.lst_str_int(app.tree_node_ls)
    tf.cal_median(app.tree_node_ls, tmp_tree_node_ls)
    app.tree_node_ls = tmp_tree_node_ls
    ''''''
    app.main_tree = Bst.BST(app.tree_node_ls)


# 初始化链表
def build_linkDS(app):
    app.link_node_ls = init_nodeList('initial_link_file')
    app.main_link = Link.LinkList(app.link_node_ls)


# 初始化循环队列
def build_queueDS(app):
    app.queue_node_ls = init_nodeList('initial_queue_file')
    app.main_queue = Qu.Queue(int(app.queue_msize_entry.get()), app.queue_node_ls)


# 将历史数据加载到数据结构中
def load_his_to_DS(app):
    if app.is_tree:
        app.main_tree = Bst.BST(app.tree_node_ls)
    if app.is_link:
        app.main_link = Link.LinkList(app.link_node_ls)
    if app.is_queue:
        app.main_queue = Qu.Queue(10, app.queue_node_ls)


# 初始化tree link queue的结点列表
def init_nodeList(f_path):
    f = open(f_path, mode='r')
    lst_nodeVal = []
    str_nodeVal = f.read().split()
    for i in str_nodeVal:
        if not i.isdigit():
            lst_nodeVal.append(i)
        else:
            lst_nodeVal.append(int(i))
    f.close()
    return lst_nodeVal
