'''
    该库是执行queue一系列操作的函数库
'''
import math
import tkinter as tk
import tkinter.messagebox
import tool_function as tf
import itertools as it
import build_DS as bd
import constant as const

my_font_15 = ('微软雅黑', 15, 'bold')
const.FOUR = 4


# 可视化queue
def visual_queue(app):
    load_data_to_lst(app)
    if app.is_queue_his:
        if app.main_queue.is_empty():
            clear_empty(app)
        else:
            clear_text(app)
            clear_front(app)
            clear_rear(app)
        bd.load_his_to_DS(app)
    else:
        app.cvs.create_text(500, 50, text='循环队列可视化界面', anchor='c', font=my_font_15)
        queue_draw_cir(app)
        app.sma_radius = tf.queue_cal_radius(app.queue_sma_rect_x1, app.queue_sma_rect_y1, app.queue_sma_rect_x2,
                                             app.queue_sma_rect_y2)
        app.big_radius = tf.queue_cal_radius(app.queue_big_rect_x1, app.queue_big_rect_y1, app.queue_big_rect_x2,
                                             app.queue_big_rect_y2, )
        app.center_pt_x, app.center_pt_y = (app.queue_big_rect_x1 + app.queue_big_rect_x2) / 2, (
                app.queue_big_rect_y1 + app.queue_big_rect_y2) / 2  # 圆心坐标
        queue_draw_line(app)
    queue_draw_text(app)
    if app.main_queue.is_empty():
        app.queue_node_dic['rear'] = [None, 0]
        pink_empty(app)
    else:
        blue_front(app)
        red_rear(app)


# 画queue的大小圆
def queue_draw_cir(app):
    # 大小圆外切正方形的四个顶点
    app.queue_big_rect_x1, app.queue_big_rect_y1 = 250, 100
    app.queue_big_rect_x2, app.queue_big_rect_y2 = 750, 600
    app.queue_sma_rect_x1, app.queue_sma_rect_y1 = 350 + 25, 200 + 25
    app.queue_sma_rect_x2, app.queue_sma_rect_y2 = 650 - 25, 500 - 25
    # 中圆的外切正方形四个顶点
    app.queue_mid_rect_x1, app.queue_mid_rect_y1 = (app.queue_big_rect_x1 + app.queue_sma_rect_x1) / 2, (
            app.queue_big_rect_y1 + app.queue_sma_rect_y1) / 2
    app.queue_mid_rect_x2, app.queue_mid_rect_y2 = (app.queue_big_rect_x2 + app.queue_sma_rect_x2) / 2, (
            app.queue_big_rect_y2 + app.queue_sma_rect_y2) / 2
    # 画大小圆
    app.cvs.create_oval(app.queue_big_rect_x1, app.queue_big_rect_y1, app.queue_big_rect_x2,
                        app.queue_big_rect_y2, width=const.FOUR)
    app.cvs.create_oval(app.queue_sma_rect_x1, app.queue_sma_rect_y1, app.queue_sma_rect_x2,
                        app.queue_sma_rect_y2, width=const.FOUR)


# queue画循环队列的分区
def queue_draw_line(app):
    app.alpha = 2 * math.pi / app.main_queue.m_size
    now_angle = 0
    app.line_pos_ls = []
    while now_angle < 2 * math.pi:
        # 划线的开始坐标以及结束坐标
        line_begin_x, line_begin_y = cal_queue_line_pos(app, app.sma_radius, now_angle)
        line_end_x, line_end_y = cal_queue_line_pos(app, app.big_radius, now_angle)
        # 下一条线的开始坐标以及结束坐标
        next_line_begin_x, next_line_begin_y = cal_queue_line_pos(app, app.sma_radius, now_angle + app.alpha)
        next_line_end_x, next_line_end_y = cal_queue_line_pos(app, app.big_radius, now_angle + app.alpha)
        # 将围成当前区域的两边的线框都加到line_pos_ls的列表中
        app.line_pos_ls.append((
            line_begin_x, line_begin_y, line_end_x, line_end_y, next_line_begin_x, next_line_begin_y,
            next_line_end_x, next_line_end_y))
        # 只画当前的线
        app.cvs.create_line(line_begin_x, line_begin_y, line_end_x, line_end_y, width=4)
        now_angle += app.alpha


# 计算分界线的起点、终点坐标
def cal_queue_line_pos(app, radius, now_angle):
    return app.center_pt_x + radius * math.sin(now_angle), app.center_pt_y - radius * math.cos(now_angle)


# 画每一个元素的create_text
def queue_draw_text(app):
    now_angle = 0.5 * app.alpha
    i = 0
    app.queue_node_dic = {}  # 存储queue的create_text，key是结点值
    for i in range(app.main_queue.get_queLength()):
        node_text_x, node_text_y, now_pos = queue_cal_text_arug(app, now_angle, i)
        node_text = app.cvs.create_text(node_text_x, node_text_y, text=app.main_queue.qu[now_pos], font=my_font_15)
        app.queue_node_dic[node_text] = [app.main_queue.qu[now_pos], tf.rad_to_dgree(now_angle - 0.5 * app.alpha)]
        now_angle += app.alpha
        i += 1
    # 为标记队尾做准备
    app.queue_node_dic['rear'] = [None, tf.rad_to_dgree(now_angle - 0.5 * app.alpha)]
    # 画enQueue结点的参数 存到元组app.enQueue_text_arug中
    enQueue_text_x, enQueue_text_y, enQueue_pos = queue_cal_text_arug(app, now_angle, i)
    app.enQueue_text_arug = (enQueue_text_x, enQueue_text_y, now_angle, i)


# 若队为空的时候，pink队头和队尾所指向的区域
def pink_empty(app):
    if not app.main_queue.is_empty():
        clear_front(app)
        clear_rear(app)
    line1_begin_x, line1_begin_y, line1_end_x, line1_end_y, line2_begin_x, line2_begin_y, line2_end_x, line2_end_y \
        = app.line_pos_ls[app.main_queue.get_front_pos()]
    extend = tf.rad_to_dgree(app.alpha)
    key = app.queue_node_dic['rear']
    angle = 0 - key[1] + 90
    app.queue_empty_Barc = app.cvs.create_arc(app.queue_big_rect_x1, app.queue_big_rect_y1, app.queue_big_rect_x2,
                                              app.queue_big_rect_y2,
                                              start=angle, extent=-extend, style='arc',
                                              outline='magenta', width=const.FOUR)
    app.queue_empty_Sarc = app.cvs.create_arc(app.queue_sma_rect_x1, app.queue_sma_rect_y1, app.queue_sma_rect_x2,
                                              app.queue_sma_rect_y2,
                                              start=angle, extent=-extend, style='arc',
                                              outline='magenta', width=const.FOUR)
    app.queue_empty_line1 = app.cvs.create_line(line1_begin_x, line1_begin_y, line1_end_x, line1_end_y,
                                                width=const.FOUR,
                                                fill='magenta')
    app.queue_empty_line2 = app.cvs.create_line(line2_begin_x, line2_begin_y, line2_end_x, line2_end_y,
                                                width=const.FOUR,
                                                fill='magenta')


# main_queue队头元素出队
def del_queue_node(app):
    if app.main_queue.get_queLength() == 1:
        clear_rear(app)
    del_node_text = find_front_in_dic(app)
    app.cvs.delete(del_node_text)  # 删除队头元素的create_text
    clear_front(app)
    app.queue_node_dic.pop(del_node_text)  # 在存储循环队列的字典中也要将出队的元素删除
    front_node_val = app.main_queue.get_front()  # 队头元素的值
    app.main_queue.de_queue()
    if not app.main_queue.is_empty():
        blue_front(app)
    if app.main_queue.is_empty():
        pink_empty(app)
    tk.messagebox.showinfo(title='提示', message='队头结点: {}已出队！'.format(front_node_val))


# 在app.queue_node_dic中找到队头元素的键值对的键
def find_front_in_dic(app):
    for k, v in app.queue_node_dic.items():
        if v[0] == app.main_queue.get_front():  # app.main_queue.get_front():
            return k


# main_queue将入队结点加到队尾
def add_queue_node(app, data):
    # 删除队空的标记
    if app.main_queue.is_empty():
        clear_empty(app)
    # 删除原队尾的标记
    if not app.main_queue.is_empty():
        clear_rear(app)
    # 真正的入队操作
    app.main_queue.en_queue(data)  # 在数据结构中入队
    enQueue_text_x, enQueue_text_y, now_angle, i = app.enQueue_text_arug  # 画 当前enQueue结点 的参数
    new_node_text = app.cvs.create_text(enQueue_text_x, enQueue_text_y, text=data, font=my_font_15)
    app.queue_node_dic[new_node_text] = [data,
                                         tf.rad_to_dgree(now_angle - 0.5 * app.alpha)]  # 将enQueue结点存到字典中
    enQueue_text_x, enQueue_text_y, enQueue_pos = queue_cal_text_arug(app, now_angle + app.alpha, i + 1)
    app.enQueue_text_arug = (enQueue_text_x, enQueue_text_y, now_angle + app.alpha, i + 1)
    # 修改队尾的角度参数
    app.queue_node_dic['rear'] = [None, tf.rad_to_dgree(now_angle + 0.5 * app.alpha)]
    # 入队之后再标记队头和队尾
    if app.main_queue.get_queLength() == 1:
        blue_front(app)
    if app.main_queue.get_queLength() >= 1:
        red_rear(app)
    app.queue_add_node_win.destroy()


# 删除cvs中的元素
def del_cvs_ele(app, cvs_ele):
    app.cvs.delete(cvs_ele)


# 计算画queue的参数
def queue_cal_text_arug(app, now_angle, i):
    now_pos = (i + app.main_queue.front) % app.main_queue.m_size  # 当前main_queue.qu的下标
    # （辅助画结点值）的线的开始坐标以及结束坐标
    text_line_begin_x, text_line_begin_y = app.center_pt_x + app.sma_radius * math.sin(
        now_angle), app.center_pt_y - app.sma_radius * math.cos(
        now_angle)
    text_line_end_x, text_line_end_y = app.center_pt_x + app.big_radius * math.sin(
        now_angle), app.center_pt_y - app.big_radius * math.cos(
        now_angle)
    # queue create_text的x，y坐标
    node_text_x, node_text_y = tf.cal_mid_point(text_line_begin_x, text_line_begin_y, text_line_end_x,
                                                text_line_end_y)
    return node_text_x, node_text_y, now_pos


# 设置循环队列自己的button样式
def queue_style(app):
    for y, text, fill in ([500, '队头：', 'blue'], [540, '队尾：', 'red'], [580, '队空：', 'magenta']):
        app.cvs.create_text(50, y, text=text, anchor='w')
        app.cvs.create_rectangle(90, y - 10, 110, y + 10, fill=fill, outline='black')


# 将队头位置的区域标注为蓝色
def blue_front(app):
    front_key = find_front_in_dic(app)
    begin_angle = 0 - app.queue_node_dic[front_key][1] + 90
    # 边框直线的参数
    front_line1_begin_x, front_line1_begin_y, front_line1_end_x, front_line1_end_y, \
    front_line2_begin_x, front_line2_begin_y, front_line2_end_x, front_line2_end_y = app.line_pos_ls[
        app.main_queue.get_front_pos()]
    # 画完整的扇形
    app.queue_front_Barc = app.cvs.create_arc(app.queue_big_rect_x1, app.queue_big_rect_y1, app.queue_big_rect_x2,
                                              app.queue_big_rect_y2,
                                              start=begin_angle, extent=0 - tf.rad_to_dgree(app.alpha), style='arc',
                                              outline='blue', width=3)
    app.queue_front_Sarc = app.cvs.create_arc(app.queue_sma_rect_x1, app.queue_sma_rect_y1, app.queue_sma_rect_x2,
                                              app.queue_sma_rect_y2,
                                              start=begin_angle, extent=0 - tf.rad_to_dgree(app.alpha), style='arc',
                                              outline='blue', width=3)
    app.queue_front_line1 = app.cvs.create_line(front_line1_begin_x, front_line1_begin_y, front_line1_end_x,
                                                front_line1_end_y, width=const.FOUR, fill='blue')
    app.queue_front_line2 = app.cvs.create_line(front_line2_begin_x, front_line2_begin_y, front_line2_end_x,
                                                front_line2_end_y, width=const.FOUR, fill='blue')


# 将队尾位置区域标注为绿色
def red_rear(app):
    rear_key = 'rear'
    begin_angle = 0 - app.queue_node_dic[rear_key][1] + 90
    rear_line1_begin_x, rear_line1_begin_y, rear_line1_end_x, rear_line1_end_y, \
    rear_line2_begin_x, rear_line2_begin_y, rear_line2_end_x, rear_line2_end_y = app.line_pos_ls[
        app.main_queue.get_rear_pos()]
    app.queue_rear_Barc = app.cvs.create_arc(app.queue_big_rect_x1, app.queue_big_rect_y1, app.queue_big_rect_x2,
                                             app.queue_big_rect_y2,
                                             start=begin_angle, extent=0 - tf.rad_to_dgree(app.alpha), style='arc',
                                             outline='red', width=const.FOUR)
    app.queue_rear_Sarc = app.cvs.create_arc(app.queue_sma_rect_x1, app.queue_sma_rect_y1, app.queue_sma_rect_x2,
                                             app.queue_sma_rect_y2,
                                             start=begin_angle, extent=0 - tf.rad_to_dgree(app.alpha), style='arc',
                                             outline='red', width=const.FOUR)
    app.queue_rear_line1 = app.cvs.create_line(rear_line1_begin_x, rear_line1_begin_y, rear_line1_end_x,
                                               rear_line1_end_y, width=const.FOUR, fill='red')
    app.queue_rear_line2 = app.cvs.create_line(rear_line2_begin_x, rear_line2_begin_y, rear_line2_end_x,
                                               rear_line2_end_y, width=const.FOUR, fill='red')


def clear_front(app):
    for i in [app.queue_front_Barc, app.queue_front_Sarc, app.queue_front_line1, app.queue_front_line2]:
        del_cvs_ele(app, i)


def clear_rear(app):
    for cvs_ele in [app.queue_rear_Barc, app.queue_rear_Sarc, app.queue_rear_line1, app.queue_rear_line2]:
        del_cvs_ele(app, cvs_ele)


def clear_empty(app):
    for cvs_ele in [app.queue_empty_Barc, app.queue_empty_Sarc, app.queue_empty_line1, app.queue_empty_line2]:
        del_cvs_ele(app, cvs_ele)


def clear_text(app):
    for i in app.queue_node_dic.keys():
        app.cvs.delete(i)


# 将文件中的历史数据加载到load_data_to_lst中
def load_data_to_lst(app):
    app.queue_history_val_lst = []
    with open('queue_history', 'r') as f:
        for line in it.islice(f, 0, None):
            tmp_his_lst = line.split()
            tf.lst_str_int(tmp_his_lst)
            app.queue_history_val_lst.append(tmp_his_lst)
